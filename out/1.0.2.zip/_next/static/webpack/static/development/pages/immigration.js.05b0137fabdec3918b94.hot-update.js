webpackHotUpdate("static/development/pages/immigration.js",[
/* 0 */,
/* 1 */
false,
/* 2 */
/*!************************************************************************************************************************************************!*\
  !*** multi next-client-pages-loader?page=%2Fimmigration&absolutePagePath=%2FUsers%2Fdanyaowang%2FSideProject%2FEllen%2Fpages%2Fimmigration.js ***!
  \************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! next-client-pages-loader?page=%2Fimmigration&absolutePagePath=%2FUsers%2Fdanyaowang%2FSideProject%2FEllen%2Fpages%2Fimmigration.js! */"./node_modules/next/dist/build/webpack/loaders/next-client-pages-loader.js?page=%2Fimmigration&absolutePagePath=%2FUsers%2Fdanyaowang%2FSideProject%2FEllen%2Fpages%2Fimmigration.js!./");


/***/ })
])
//# sourceMappingURL=immigration.js.05b0137fabdec3918b94.hot-update.js.map